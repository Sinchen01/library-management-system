﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using library_management_system.dllTableAdapters;
using System.Data;

namespace library_management_system
{
    public class bll
    {
        tblAdminTableAdapter Admin_Adpt = new tblAdminTableAdapter();
        tblbookTableAdapter Book_Adpt = new tblbookTableAdapter();
        tblUserTableAdapter User_Adpt = new tblUserTableAdapter();
        tblComplaintTableAdapter Complaint_Adpt = new tblComplaintTableAdapter();
        tblDepositTableAdapter Deposit_Adpt = new tblDepositTableAdapter();
        tblBorrowerTableAdapter Borrower_Adpt = new tblBorrowerTableAdapter();

        //Admin
        public int IsvalideAdmin(string LoginId, string Password)
        {
            return (int)Admin_Adpt.IsvalidAdmin(LoginId, Password);
        }
        public DataTable getall_Admin(string LoginId, string Password)
        {
            return Admin_Adpt.GetDataBy1(LoginId, Password);
        }
       //User
        public int AddUser(string name, string emailid, string password, string contact)
        {
            return User_Adpt.AddUser(name,emailid,password,contact);
        }
        public int Checkuser(string Emailid)
        {
            return (int)User_Adpt.CheckEmailId(Emailid);
        }
        public int IsvalideUser(string EmailId, string Password)
        {
            return (int)User_Adpt.IsvalidUser(EmailId, Password);
        }
        public DataTable get_userid(int userid)
        {
            return User_Adpt.GetDataBy4(userid);
        }
        public DataTable get_user(string EmailId, string Password)
        {
            return User_Adpt.GetDataBy2(EmailId, Password);
        }
        public DataTable get_allUsers()
        {
            return User_Adpt.GetData();
        }
        //Book
        public int AddBooks(string BookSerialno, string Bookname, string BookAuthorname, string Quantity)
        {
            return Book_Adpt.Addbook(BookSerialno, Bookname, BookAuthorname, Quantity);
        }
        public int CheckBook(string BookSerialno)
        {
            return (int)Book_Adpt.Checkbook(BookSerialno);
        }
        public DataTable Get_BookId(int BookId)
        {
            return Book_Adpt.GetDataBy4(BookId);
        }
        public DataTable Get_Search_books(string bookname)
        {
            return Book_Adpt.GetDataBy5(bookname);
        }
        public DataTable Get_AllBook()
        {
            return Book_Adpt.GetData();
        }
        public int UpdateQuantity(string Quantity, int BookId)
        {
            return Book_Adpt.Bookupdate(Quantity, BookId);
        }
        //Complaint
        public int AddComplaint(int UserId,string Date, string Complaint)
        {
            return Complaint_Adpt.PostComplaint(UserId, Date, Complaint);
        }
        public DataTable Get_Complaint_UserId(int UserId)
        {
            return Complaint_Adpt.GetDataBy1(UserId);
        }
        public DataTable Get_AllComplaint()
        {
            return Complaint_Adpt.GetDataBy2();
        }
        //Deposit
        public int AddDeposite(int UserId, string Amount)
        {
            return Deposit_Adpt.AddDesposit(UserId, Amount);
        }
        public int CheckDepositeId(int UserId)
        {
            return (int)Deposit_Adpt.CheckDeposit(UserId);
        }
        public DataTable Get_DepositId(int UserId)
        {
            return Deposit_Adpt.GetDataBy2(UserId);
        }
        public DataTable Get_Deposite()
        {
            return Deposit_Adpt.GetDataBy3();
        }
        //Borrower
        public int AddBorrower(int BookId,int UserId, string Issue_date, string Return_Date)
        {
            return Borrower_Adpt.UploadBorrower(BookId,UserId, Issue_date, Return_Date);
        }
        public DataTable Get_BorrowerID(int UserId)
        {
            return Borrower_Adpt.GetDataBy1(UserId);
        }
        public DataTable Get_AllBorrower()
        {
            return Borrower_Adpt.GetDataBy2();
        }
        public int CheckBookissue(int UserId,int BookId)
        {
            return (int)Borrower_Adpt.Checkbookissue(UserId, BookId);
        }
    }
}