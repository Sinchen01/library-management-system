﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace library_management_system.user
{
    public partial class Searchbooks : System.Web.UI.Page
    {
        bll b = new bll();
        DataTable Tab;
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
        

        protected void pro_btn_Click(object sender, EventArgs e)
        {
            GridView1.DataSource = b.Get_Search_books(txtBookName.Text);
            GridView1.DataBind();
        }
    }
}