﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace library_management_system.user
{
    public partial class Complaint : System.Web.UI.Page
    {
        bll b = new bll();
        int UserId;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserId = int.Parse(Session["UserId"].ToString());

        }
        public void Get_AllUsers()
        {
            GridView1.DataSource = b.Get_Complaint_UserId(UserId);
            GridView1.DataBind();
        }
        protected void pro_btn_Click(object sender, EventArgs e)
        {
            int res1 = b.AddComplaint(UserId, txtdate.Text, txtcomplaint.Text);
            if (res1 == 1)
            {
                Response.Write("<script>alert('Complaint Posted!!')</script>");
                txtcomplaint.Text = "";
                txtdate.Text = "";
                Get_AllUsers();

            }
            else
            {
                Response.Write("<script>alert('Error..!!')</script>");
            }
        }
    }
}