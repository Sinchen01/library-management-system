﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace library_management_system.user
{
    public partial class AddDeposite : System.Web.UI.Page
    {
        bll b = new bll();
        int UserId;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserId = int.Parse(Session["UserId"].ToString());
            if (!IsPostBack)
            {
                Get_Deposite();
            }
        }
        public void Get_Deposite()
        {
            GridView1.DataSource = b.Get_DepositId(UserId);
            GridView1.DataBind();
        }
        
    }
}