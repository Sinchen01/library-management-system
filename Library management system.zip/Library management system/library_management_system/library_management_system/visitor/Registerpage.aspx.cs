﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using library_management_system.dllTableAdapters;
using System.Data;

namespace library_management_system.visitor
{
    public partial class Registerpage : System.Web.UI.Page
    {
        bll b = new bll();
        DataTable Tab;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Register_btn_Click(object sender, EventArgs e)
        {
            int res = b.Checkuser(txtemailid.Text);
            if (res == 1)
            {
                Response.Write("<script>alert('User already  Registered')</script>");

            }
            else
            {
                int res1 = b.AddUser(txtname.Text,txtemailid.Text, txtpassword.Text, txtphone.Text);
                if (res1 == 1)
                {
                    Response.Write("<script>alert('User Registered..!!')</script>");
                    txtname.Text="";
                    txtemailid.Text="";
                    txtpassword.Text="";
                    txtphone.Text = "";
                }
                else
                {
                    Response.Write("<script>alert('Error..!!')</script>");
                }
            }
        }
    }
}