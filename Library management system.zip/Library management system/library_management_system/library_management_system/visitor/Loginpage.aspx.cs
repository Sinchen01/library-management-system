﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using library_management_system.dllTableAdapters;
using System.Data;

namespace library_management_system.visitor
{
    public partial class Loginpage : System.Web.UI.Page
    {
        bll b = new bll();
        DataTable Tab;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Login_btn_Click(object sender, EventArgs e)
        {
            int n;
            switch (DropDownList1.SelectedItem.Text)
            {
                case "Admin": n = b.IsvalideAdmin(txtloginid.Text, txtpassword.Text);
                    if (n == 1)
                    {
                        Tab = b.getall_Admin(txtloginid.Text, txtpassword.Text);
                        Session["AdminId"] = Tab.Rows[0]["AdminId"].ToString();
                        Response.Redirect("~/admin/Admin.aspx");
                    }
                    else
                    {
                        Response.Write("<script>alert('Invalide LoginId and Password')</script>");
                    }
                    break;

                case "Member":
                    n = b.IsvalideUser(txtloginid.Text, txtpassword.Text);
                    if (n == 1)
                    {
                        Tab = b.get_user(txtloginid.Text, txtpassword.Text);
                        Session["UserId"] = Tab.Rows[0]["UserId"].ToString();
                        Response.Redirect("~/user/User.aspx");
                    }
                    else
                    {
                        Response.Write("<script>alert('Invalide LoginId and Password')</script>");
                    }

                    break;

            }
        }
    }
}