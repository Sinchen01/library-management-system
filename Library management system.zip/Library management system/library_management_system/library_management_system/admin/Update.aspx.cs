﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using library_management_system.dllTableAdapters;

namespace library_management_system.admin
{
    public partial class Update : System.Web.UI.Page
    {
        bll b = new bll();
        DataTable Tab;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                bindbooks();
                MultiView1.SetActiveView(View1);
            }
        }
        public void bindbooks()
        {
            DropDownList1.DataSource = b.Get_AllBook();
            DropDownList1.DataTextField = "Bookname";
            DropDownList1.DataValueField = "BookId";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, "Select");
        }
        protected void pro_btn_Click(object sender, EventArgs e)
        {
            Tab = b.Get_BookId(int.Parse(DropDownList1.SelectedItem.Value));
            txtQuantity.Text = Tab.Rows[0]["Quantity"].ToString();
            pro_btn.CommandArgument = DropDownList1.SelectedItem.Value;
            MultiView1.SetActiveView(View2);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int res = b.UpdateQuantity(txtQuantity.Text, int.Parse(pro_btn.CommandArgument));
            if (res == 1)
            {
                Response.Write("<script>alert('Book Quantity Updated')</script>");
                MultiView1.SetActiveView(View1);
            }
            else
            {
                Response.Write("<script>alert('Error..!!!!!')</script>");
               
            }
           
        }
    }
}