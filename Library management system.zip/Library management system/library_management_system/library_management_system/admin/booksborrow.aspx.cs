﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace library_management_system.admin
{
    public partial class booksborrow : System.Web.UI.Page
    {
        bll b = new bll();
        DataTable Tab;
       
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (!IsPostBack)
            {
                bindborrower();

            }
        }
        public void bindborrower()
        {
            GridView1.DataSource = b.Get_AllBorrower();
            GridView1.DataBind();
        }
    }
}