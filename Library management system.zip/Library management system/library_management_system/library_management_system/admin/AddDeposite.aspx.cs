﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace library_management_system.admin
{
    public partial class AddDeposite : System.Web.UI.Page
    {
        bll b = new bll();
        int UserId;
        protected void Page_Load(object sender, EventArgs e)
        {
          
            if (!IsPostBack)
            {
              
                getuser();
            }
        }
        public void getuser()
        {
            DropDownList1.DataSource = b.get_allUsers();
            DropDownList1.DataTextField = "Name";
            DropDownList1.DataValueField = "UserId";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, "Select");
        }
        public void Get_Deposite()
        {
            GridView1.DataSource = b.Get_DepositId(int.Parse(DropDownList1.SelectedItem.Value));
            GridView1.DataBind();
        }
        protected void pro_btn_Click(object sender, EventArgs e)
        {
            int res = b.CheckDepositeId(int.Parse(DropDownList1.SelectedItem.Value));
            if (res == 1)
            {
                Response.Write("<script>alert('One Time Deposite Already Done')</script>");
                Get_Deposite();
            }
            else
            {
                int res1 = b.AddDeposite(int.Parse(DropDownList1.SelectedItem.Value), txtDeposition.Text);
                if (res1 == 1)
                {
                    Response.Write("<script>alert('Amount Deposited..!!')</script>");
                    txtDeposition.Text = "";
                    Get_Deposite();

                }
                else
                {
                    Response.Write("<script>alert('Error..!!')</script>");
                    txtDeposition.Text = "";
                    Get_Deposite();
                }
            }
        }
    }
}