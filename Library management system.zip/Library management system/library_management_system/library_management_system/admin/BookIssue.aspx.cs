﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace library_management_system.admin
{
    public partial class BookIssue : System.Web.UI.Page
    {
        bll b = new bll();
        DataTable Tab;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindUser();
                BindBooks();
                bindborrower();

            }
        }
        public void BindBooks()
        {
            DropDownList2.DataSource = b.Get_AllBook();
            DropDownList2.DataTextField = "Bookname";
            DropDownList2.DataValueField = "BookId";
            DropDownList2.DataBind();
            DropDownList2.Items.Insert(0, "Select");
        }
        public void BindUser()
        {
            DropDownList1.DataSource = b.Get_Deposite();
            DropDownList1.DataTextField = "Name";
            DropDownList1.DataValueField = "UserId";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, "Select");
        }
        public void bindborrower()
        {
            GridView1.DataSource = b.Get_AllBorrower();
            GridView1.DataBind();
        }
        protected void pro_btn_Click(object sender, EventArgs e)
        {
            int x=b.CheckBookissue(int.Parse(DropDownList1.SelectedItem.Value),int.Parse(DropDownList2.SelectedItem.Value));
            if(x==1)
            {
                Response.Write("<script>alert('This Book Already Borrowred..!!')</script>");
                DropDownList1.ClearSelection();
            }
            else
            {
                Tab = b.Get_BookId(int.Parse(DropDownList2.SelectedItem.Value));
                int Quantity = int.Parse(Tab.Rows[0]["Quantity"].ToString());
                int UQuantity = Quantity - 1;
                b.UpdateQuantity(UQuantity.ToString(), int.Parse(DropDownList2.SelectedItem.Value));
                int res1 = b.AddBorrower(int.Parse(DropDownList2.SelectedItem.Value), int.Parse(DropDownList1.SelectedItem.Value), txtIssueDate.Text, txtReturnDate.Text);
                if (res1 == 1)
                 {
                   Response.Write("<script>alert('New Book Borrower Details Uploaded..!!')</script>");
                    DropDownList1.ClearSelection();
                    txtIssueDate.Text = "";
                     txtReturnDate.Text = "";
                    bindborrower();
                 }
            else
            {
                Response.Write("<script>alert('Error..!!')</script>");
            }
            }
           
        }
    }
}