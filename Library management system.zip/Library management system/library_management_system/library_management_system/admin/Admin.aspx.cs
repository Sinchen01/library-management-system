﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using library_management_system.dllTableAdapters;
using System.Data;

namespace library_management_system.admin
{
    public partial class Admin1 : System.Web.UI.Page
    {
        bll b = new bll();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getbooks();
            }
        }
        public void getbooks()
        {
            GridView1.DataSource = b.Get_AllBook();
            GridView1.DataBind();
        }
        protected void pro_btn_Click(object sender, EventArgs e)
        {
            int res = b.CheckBook(txtbookid.Text);
            if (res == 1)
            {
                Response.Write("<script>alert('Book already Uploaded')</script>");
                getbooks();

            }
            else
            {
                int res1 = b.AddBooks(txtbookid.Text, txtBookName.Text, txtAuthorName.Text, txtquantity.Text);
                if (res1 == 1)
                {
                   Response.Write("<script>alert('New Book Details Uploaded..!!')</script>");
                   txtbookid.Text="";
                   txtBookName.Text="";
                   txtAuthorName.Text="";
                   txtquantity.Text = "";
                   getbooks();
                
                }
                else
                {
                    Response.Write("<script>alert('Error..!!')</script>");
                }
            }
        }
    }
}